﻿using System.ComponentModel.DataAnnotations;

namespace GROWGREEN.Models
{
    public class QueryFormViewModel
    {
        public int ExpertId { get; set; }

        public string ExpertName { get; set; }

        [Required(ErrorMessage = "Query cannot be empty.")]
        public string Query { get; set; }
    }
}
