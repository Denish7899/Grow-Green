﻿namespace GROWGREEN.Models
{
    public class FarmerRequestViewModel
    {
        public int RequestId { get; set; }
        public string FarmerName { get; set; }
        public string FarmerEmail { get; set; }
        public string FarmerPhone { get; set; }
        public DateTime RequestDate { get; set; }
        public string Query { get; set; }
    }
}
