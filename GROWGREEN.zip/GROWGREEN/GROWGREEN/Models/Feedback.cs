﻿
using System.ComponentModel.DataAnnotations;

namespace GROWGREEN.Models 
{

    public class Feedback
    {
        [Key]
        public int Feedback_Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [Required]
        [EmailAddress]
        [StringLength(100)]
        public string Email { get; set; }

        [Required]
        [Range(1, 5)]
        public int Rating { get; set; }

        [Required]
        public string Comment { get; set; }
    }

}
