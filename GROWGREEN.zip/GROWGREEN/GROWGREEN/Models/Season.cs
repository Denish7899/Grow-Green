﻿using System.ComponentModel.DataAnnotations;

namespace GROWGREEN.Models
{
    public class Season
    {
        [Key]
        public int SeasonId { get; set; }

        [Required]
        public string SeasonName { get; set; } = string.Empty;

        public ICollection<FarmingProgram>? FarmingPrograms { get; set; }
    }

}