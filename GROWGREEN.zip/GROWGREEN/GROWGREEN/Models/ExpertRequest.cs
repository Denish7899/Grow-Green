﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GROWGREEN.Models
{
    public class ExpertRequest
    {
        [Key]
        public int RequestId { get; set; }

        [Required]
        public int FarmerId { get; set; }

        [ForeignKey("FarmerId")]
        public virtual Farmer Farmer { get; set; }

        [Required]
        public int ExpertId { get; set; }

        [ForeignKey("ExpertId")]
        public virtual Expert Expert { get; set; }

        [Required]
        [StringLength(500)]
        public string Query { get; set; }

        [Required]
        public DateTime RequestDate { get; set; }
    }
}
