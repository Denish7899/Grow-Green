﻿using GROWGREEN.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

public class SelectedProgram
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int FarmerId { get; set; }

    [Required]
    public int ProgramId { get; set; }

    public DateTime SelectedDate { get; set; } = DateTime.Now;

    public DateTime? StartDate { get; set; }

    public bool IsStarted { get; set; } = false;

    [ForeignKey("FarmerId")]
    public virtual Farmer Farmer { get; set; }

    [ForeignKey("ProgramId")]
    public virtual FarmingProgram Program { get; set; }

    public DateTime? EndDate { get; set; }
}
