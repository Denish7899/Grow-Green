﻿using System.ComponentModel.DataAnnotations;

namespace GROWGREEN.Models
{
    public class RegisterViewModel
{
        [Required(ErrorMessage = "Name is required.")]
        [StringLength(50)]
    [RegularExpression(@"^[A-Za-z\s]+$", ErrorMessage = "Name can only contain alphabets and spaces.")]
     public string F_Name { get; set; }

    [Required, EmailAddress]
    public string F_Email { get; set; }

    [Required]
    [Phone]
    [MaxLength (10)]
    [RegularExpression(@"^(?!([0-9])\1{9})\d{10}$", ErrorMessage = "Invalid phone number.")]
        public string F_PhoneNo { get; set; }

    [Required]
    public string F_City { get; set; }

    [Required]
    public string F_Gender { get; set; }

    [Required, DataType(DataType.Password)]
        [MaxLength(8)]
        public string Password { get; set; }

    [Required, DataType(DataType.Password), Compare("Password", ErrorMessage = "Passwords do not match.")]
        [MaxLength(8)]
        public string ConfirmPassword { get; set; }
}


}
