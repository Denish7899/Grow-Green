﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace GROWGREEN.Models;

public partial class GrowgreenContext : DbContext
{
    public GrowgreenContext()
    {
    }

    public GrowgreenContext(DbContextOptions<GrowgreenContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Admin> Admin { get; set; }

    public virtual DbSet<Farmer> Farmer { get; set; }
    public virtual DbSet<Expert> Expert { get; set; }

    public DbSet<SelectedProgram> SelectedPrograms { get; set; }

    // Use plural for DbSet


    public DbSet<Season> Seasons { get; set; }
    public DbSet<FarmingProgram> FarmingPrograms { get; set; }



    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=(localdb)\\ProjectModels; Database=GROWGREEN; Trusted_Connection=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Admin>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Admin__3214EC073FC4C69B");

            entity.ToTable("Admin");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.Email).HasMaxLength(50);
            entity.Property(e => e.Name).HasMaxLength(50);
            entity.Property(e => e.Password).HasMaxLength(50);
            entity.Property(e => e.Phone).HasMaxLength(20);
        });

        modelBuilder.Entity<Farmer>(entity =>
        {
            entity.HasKey(e => e.F_Id).HasName("PK__Farmer__2C6EC7234FEE629B");

            entity.ToTable("Farmer");

            entity.Property(e => e.F_Id)
                .ValueGeneratedNever()
                .HasColumnName("F_Id");
            entity.Property(e => e.F_City)
                .HasMaxLength(50)
                .HasColumnName("F_City");
            entity.Property(e => e.F_Email)
                .HasMaxLength(50)
                .HasColumnName("F_Email");
            entity.Property(e => e.F_Gender)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("F_Gender");
            entity.Property(e => e.F_Name)
                .HasMaxLength(50)
                .HasColumnName("F_Name");
            entity.Property(e => e.F_PhoneNo)
                .HasColumnType("numeric(10, 0)")
                .HasColumnName("F_PhoneNo");
            entity.Property(e => e.Password).HasMaxLength(50);
            entity.Property(e => e.R_Date)
                .IsRowVersion()
                .IsConcurrencyToken()
                .HasColumnName("R_Date");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
