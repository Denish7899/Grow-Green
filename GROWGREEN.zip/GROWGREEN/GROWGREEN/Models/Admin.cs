﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GROWGREEN.Models;

public partial class Admin
{
    [Key]
    public int Id { get; set; }

    [Required]
    [StringLength(50)]
    [RegularExpression(@"^[A-Za-z\s]+$", ErrorMessage = "Name can only contain alphabets and spaces.")]
    public string? Name { get; set; }

    [Required, EmailAddress]
    public string? Email { get; set; }

    [Required]
    [Phone]
    [MaxLength(10)]
    [RegularExpression(@"^(?!([0-9])\1{9})\d{10}$", ErrorMessage = "Invalid phone number.")]
    public string? Phone { get; set; }

    public string? Password { get; set; }
}
