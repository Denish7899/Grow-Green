﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace GROWGREEN.Models
{
    public class Expert
    {
        [Key]
        public int E_Id { get; set; }

        [Required]
        [RegularExpression(@"^[A-Za-z\s]+$", ErrorMessage = "Name can only contain alphabets and spaces.")]
        public string E_Name { get; set; }

        [Required]
        [Phone]
        [MaxLength(10)]
        [RegularExpression(@"^(?!([0-9])\1{9})\d{10}$", ErrorMessage = "Invalid phone number.")]
        public string E_PhoneNo { get; set; }

        [Required, EmailAddress]
        public string E_Email { get; set; }

        [Required]
        public string E_Expertise { get; set; }

        [ValidateNever]
        public string E_Password { get; set; }

        public bool IsEdit => E_Id > 0;

        [Required]
        public string E_Gender { get; set; }

        [ValidateNever]
        public ICollection<ExpertRequest> ExpertRequests { get; set; }

    }

}
