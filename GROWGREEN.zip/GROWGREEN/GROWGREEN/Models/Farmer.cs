﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GROWGREEN.Models;

public class Farmer
{
    [Key]
    public int F_Id { get; set; }

    [Required(ErrorMessage = "Name is required.")]
    [StringLength(20)]
    [RegularExpression(@"^[A-Za-z\s]+$", ErrorMessage = "Name can only contain alphabets and spaces.")]
    public string F_Name { get; set; }

    [Required]
    [Phone]
    [StringLength(13, ErrorMessage = "Phone number must be 10 digits or start with +91.")]
    [RegularExpression(@"^(\+91)?\d{10}$", ErrorMessage = "Invalid phone number.")]
    public string F_PhoneNo { get; set; }


    [Required]
    public string F_City { get; set; }

    [Required]
    [EmailAddress]
    public string F_Email { get; set; }

    [Required]
    public string F_Gender { get; set; }

    [Required]
    [MaxLength(8)]
    public string Password { get; set; }

    [Required]
    public DateTime R_Date { get; set; } = DateTime.Now;

}

