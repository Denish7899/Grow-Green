﻿using Microsoft.EntityFrameworkCore;

namespace GROWGREEN.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Admin> Admin { get; set; }
        public DbSet<Farmer> Farmer { get; set; }

        public DbSet<Expert> Expert { get; set; }

        public DbSet<Feedback> Feedback { get; set; }
        public DbSet<Season> Seasons { get; set; }
        public DbSet<FarmingProgram> FarmingPrograms { get; set; }
        public DbSet<SelectedProgram> SelectedPrograms { get; set; }
        public DbSet<ExpertRequest> ExpertRequests { get; set; }
        public DbSet<ProgramReminder> ProgramReminders { get; set; }
        public DbSet<ChatMessage> ChatMessages { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ExpertRequest>()
                .Property(e => e.RequestDate)
                .HasDefaultValueSql("GETDATE()");

            modelBuilder.Entity<ExpertRequest>()
                .HasOne(er => er.Expert)
                .WithMany(e => e.ExpertRequests)
                .HasForeignKey(er => er.ExpertId)
                .OnDelete(DeleteBehavior.Cascade);

            base.OnModelCreating(modelBuilder);
        }


        public override int SaveChanges()
        {
            return base.SaveChanges();
        }
    }
}
