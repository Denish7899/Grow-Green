﻿namespace GROWGREEN.Models
{
    public class ProgramReminder
    {
        public int Id { get; set; }
        public int SelectedProgramId { get; set; }
        public int RemainingDays { get; set; }
        public DateTime SentDate { get; set; }
    }

}
