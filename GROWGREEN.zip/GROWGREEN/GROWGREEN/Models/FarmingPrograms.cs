﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace GROWGREEN.Models
{
    public class FarmingProgram
    {
        [Key]
        public int ProgramId { get; set; }

        [Required]
        public string ProgramName { get; set; } = string.Empty;

        [Required]
        public string CropName { get; set; } = string.Empty;

        [Required]
        public string SowingTime { get; set; } = string.Empty;

        [Required]
        public string TimeDuration { get; set; } = string.Empty;

        [Required]
        public string IrrigationSchedule { get; set; } = string.Empty;

        [Required]
        public string FertilizerRecommendation { get; set; } = string.Empty;

        [Required]
        [ForeignKey("Season")]
        public int SeasonId { get; set; }

        public string? ImagePath { get; set; }


        public Season? Season { get; set; }

        [Required]
        public DateTime CreatedDate { get; set; }

    }
}
