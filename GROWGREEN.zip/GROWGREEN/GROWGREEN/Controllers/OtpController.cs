﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

public class OtpController : Controller
{
    private readonly OtpService _otpService;

    public OtpController(OtpService otpService)
    {
        _otpService = otpService;
    }

    [HttpGet]
    public IActionResult SendOtp()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> SendOtp(string email)
    {
        await _otpService.GenerateAndSendOtp(email);
        TempData["email"] = email;
        return RedirectToAction("VerifyOtp");
    }

    [HttpGet]
    public IActionResult VerifyOtp()
    {
        ViewBag.Email = TempData["email"];
        return View();
    }

    [HttpPost]
    public IActionResult VerifyOtp(string email, string otp)
    {
        if (_otpService.VerifyOtp(email, otp))
        {
            return RedirectToAction("OtpSuccess");
        }

        ViewBag.Email = email;
        ViewBag.Error = "Invalid OTP. Try again.";
        return View();
    }

    public IActionResult OtpSuccess()
    {
        return Content("✅ OTP Verified Successfully!");
    }
}
