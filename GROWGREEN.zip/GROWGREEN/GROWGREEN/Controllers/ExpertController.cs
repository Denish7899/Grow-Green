﻿using GROWGREEN.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Collections.Generic;

namespace GROWGREEN.Controllers
{
    public class ExpertController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ExpertController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Chat()
        {
            var messages = _context.ChatMessages
                .OrderBy(m => m.Timestamp)
                .ToList();

            ViewBag.ChatMessages = messages;

            // Auto-fill username from session
            ViewBag.Username = HttpContext.Session.GetString("FarmerEmail")
                   ?? HttpContext.Session.GetString("ExpertEmail");

            return View();
        }


        public IActionResult Dashboard()
        {
            return View();
        }
        public IActionResult ShowFarmerRequests()
        {
            int? expertId = HttpContext.Session.GetInt32("ExpertId");

            if (expertId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var farmerQueries = _context.ExpertRequests
                .Where(r => r.ExpertId == expertId)
                .Select(r => new FarmerRequestViewModel
                {
                    RequestId = r.RequestId,
                    FarmerName = r.Farmer.F_Name,
                    FarmerEmail = r.Farmer.F_Email,
                    FarmerPhone = r.Farmer.F_PhoneNo,
                    RequestDate = r.RequestDate,
                    Query = r.Query
                }).ToList();

            return View(farmerQueries);
        }

    }
}
