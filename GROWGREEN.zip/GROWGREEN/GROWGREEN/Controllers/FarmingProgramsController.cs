﻿using GROWGREEN.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.IO;

namespace GROWGREEN.Controllers
{
    public class FarmingProgramsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public FarmingProgramsController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index(string searchQuery)
        {
            var programs = _context.FarmingPrograms.Include(f => f.Season).AsQueryable();

            // Filter by search query
            if (!string.IsNullOrEmpty(searchQuery))
            {
                programs = programs.Where(fp =>
                    fp.ProgramName.Contains(searchQuery) ||
                    fp.CropName.Contains(searchQuery) ||
                    fp.SowingTime.Contains(searchQuery) ||
                    fp.TimeDuration.Contains(searchQuery) ||
                    fp.IrrigationSchedule.Contains(searchQuery) ||
                    fp.FertilizerRecommendation.Contains(searchQuery) ||
                    fp.Season.SeasonName.Contains(searchQuery));
            }

            // Order programs by CreatedDate descending to display the latest first
            programs = programs.OrderByDescending(fp => fp.CreatedDate);

            return View(programs.ToList());
        }

        public IActionResult Create()
        {
            ViewBag.Seasons = new SelectList(_context.Seasons, "SeasonId", "SeasonName");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(FarmingProgram farmingProgram, IFormFile CropImage)
        {
            if (ModelState.IsValid)
            {
                // Set CreatedDate if not already set
                farmingProgram.CreatedDate = DateTime.UtcNow; // Or DateTime.Now if you prefer local time

                if (CropImage != null && CropImage.Length > 0)
                {
                    var extension = Path.GetExtension(CropImage.FileName).ToLower();
                    var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif" };

                    if (!allowedExtensions.Contains(extension))
                    {
                        ModelState.AddModelError("CropImage", "Only image files (.jpg, .jpeg, .png, .gif) are allowed.");
                        ViewBag.Seasons = new SelectList(_context.Seasons, "SeasonId", "SeasonName");
                        return View(farmingProgram);
                    }

                    var fileName = Path.GetFileNameWithoutExtension(CropImage.FileName);
                    var uniqueFileName = $"{fileName}_{Guid.NewGuid()}{extension}";

                    var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/Images/crops");
                    Directory.CreateDirectory(uploadsFolder); // Makes sure the folder exists

                    var filePath = Path.Combine(uploadsFolder, uniqueFileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        CropImage.CopyTo(stream);
                    }

                    farmingProgram.ImagePath = "/Images/crops/" + uniqueFileName;
                }

                _context.FarmingPrograms.Add(farmingProgram);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Seasons = new SelectList(_context.Seasons, "SeasonId", "SeasonName");
            return View(farmingProgram);
        }

        public IActionResult Edit(int id)
        {
            var farmingProgram = _context.FarmingPrograms.Find(id);
            if (farmingProgram == null) return NotFound();

            // Set the CreatedDate only during creation, not on edit
            ViewBag.Seasons = new SelectList(_context.Seasons, "SeasonId", "SeasonName", farmingProgram.SeasonId);
            return View(farmingProgram);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, FarmingProgram farmingProgram)
        {
            if (id != farmingProgram.ProgramId) return NotFound();

            if (ModelState.IsValid)
            {
                var originalProgram = _context.FarmingPrograms.AsNoTracking().FirstOrDefault(fp => fp.ProgramId == id);
                if (originalProgram == null) return NotFound();

                // Retain CreatedDate from the original program if being edited
                farmingProgram.CreatedDate = originalProgram.CreatedDate;

                _context.Update(farmingProgram);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Seasons = new SelectList(_context.Seasons, "SeasonId", "SeasonName", farmingProgram.SeasonId);
            return View(farmingProgram);
        }

        public IActionResult Delete(int id)
        {
            var farmingProgram = _context.FarmingPrograms.Include(f => f.Season).FirstOrDefault(m => m.ProgramId == id);
            if (farmingProgram == null) return NotFound();

            return View(farmingProgram);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var farmingProgram = _context.FarmingPrograms.Find(id);
            if (farmingProgram != null)
            {
                var selectedPrograms = _context.SelectedPrograms.Where(sp => sp.ProgramId == id).ToList();
                _context.SelectedPrograms.RemoveRange(selectedPrograms);

                _context.FarmingPrograms.Remove(farmingProgram);
                _context.SaveChanges();
            }

            return RedirectToAction("Index");
        }

        public IActionResult EditImage(int id)
        {
            var program = _context.FarmingPrograms.Find(id);
            if (program == null) return NotFound();

            return View(program);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditImage(int id, IFormFile NewImage)
        {
            var program = _context.FarmingPrograms.Find(id);
            if (program == null) return NotFound();

            if (NewImage != null && NewImage.Length > 0)
            {
                var extension = Path.GetExtension(NewImage.FileName).ToLower();
                var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif" };

                if (!allowedExtensions.Contains(extension))
                {
                    ModelState.AddModelError("ImagePath", "Only image files (.jpg, .jpeg, .png, .gif) are allowed.");
                    return View(program);
                }

                var fileName = Path.GetFileNameWithoutExtension(NewImage.FileName);
                var uniqueFileName = $"{fileName}_{Guid.NewGuid()}{extension}";

                var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/Images/crops");
                Directory.CreateDirectory(uploadsFolder);

                var filePath = Path.Combine(uploadsFolder, uniqueFileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    NewImage.CopyTo(stream);
                }

                program.ImagePath = "/Images/crops/" + uniqueFileName;
                _context.SaveChanges();
                return RedirectToAction("Index");
            }

            ModelState.AddModelError("ImagePath", "Please upload a valid image.");
            return View(program);
        }
    }
}
