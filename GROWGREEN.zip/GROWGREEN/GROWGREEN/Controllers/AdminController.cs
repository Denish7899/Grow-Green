﻿using GROWGREEN.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

public class AdminController : Controller
{
    private readonly ApplicationDbContext _context;

    public AdminController(ApplicationDbContext context)
    {
        _context = context;
    }

    public IActionResult Dashboard()
    {
        return View();
    }

    public IActionResult ManageExperts()
    {
        var experts = _context.Expert.ToList();
        return View(experts);
    }

    public IActionResult ManageFarmers()
    {
        var Farmer = _context.Farmer.ToList();
        return View(Farmer);
    }

    public IActionResult ManageFeedBack()
    {
        var feedbacks = _context.Feedback.ToList();
        return View(feedbacks);
    }

    public IActionResult EditExpert(int? id)
    {
        if (id == null || id == 0)
        {
            return View(new Expert());
        }

        var expert = _context.Expert.Find(id);
        if (expert == null)
        {
            return NotFound();
        }

        // Do not expose password in edit
        var viewModel = new Expert
        {
            E_Id = expert.E_Id,
            E_Name = expert.E_Name,
            E_PhoneNo = expert.E_PhoneNo,
            E_Email = expert.E_Email,
            E_Expertise = expert.E_Expertise,
            E_Gender = expert.E_Gender
        };

        return View(viewModel);
    }

    [HttpPost]
    public IActionResult EditExpert(Expert model)
    {
        // Manually enforce password required only on add
        if (model.E_Id == 0 && string.IsNullOrWhiteSpace(model.E_Password))
        {
            ModelState.AddModelError("E_Password", "Password is required.");
        }

        if (ModelState.IsValid)
        {
            if (model.E_Id == 0)
            {
                // New Expert — encrypt and store password
                var newExpert = new Expert
                {
                    E_Name = model.E_Name,
                    E_PhoneNo = model.E_PhoneNo,
                    E_Email = model.E_Email,
                    E_Expertise = model.E_Expertise,
                    E_Gender = model.E_Gender,
                    E_Password = EncryptionHelper.EncryptPassword(model.E_Password)
                };

                _context.Expert.Add(newExpert);
            }
            else
            {
                // Edit existing expert
                var existingExpert = _context.Expert.Find(model.E_Id);
                if (existingExpert != null)
                {
                    existingExpert.E_Name = model.E_Name;
                    existingExpert.E_PhoneNo = model.E_PhoneNo;
                    existingExpert.E_Email = model.E_Email;
                    existingExpert.E_Expertise = model.E_Expertise;
                    existingExpert.E_Gender = model.E_Gender;

                    // Update password only if a new one is entered
                    if (!string.IsNullOrWhiteSpace(model.E_Password))
                    {
                        existingExpert.E_Password = EncryptionHelper.EncryptPassword(model.E_Password);
                    }
                }
            }

            _context.SaveChanges();
            return RedirectToAction("ManageExperts");
        }

        return View(model);
    }


    public IActionResult DeleteExpert(int id)
    {
        var expert = _context.Expert.Find(id);
        if (expert != null)
        {
            _context.Expert.Remove(expert);
            _context.SaveChanges();
        }

        return RedirectToAction("ManageExperts");
    }

}
