﻿using Microsoft.AspNetCore.Mvc;
using GROWGREEN.Models;
using Microsoft.EntityFrameworkCore;

public class FeedBackController : Controller
{
    private readonly ApplicationDbContext _context;

    public FeedBackController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(Feedback feedback)
    {
        if (ModelState.IsValid)
        {
            var feedbackCount = _context.Feedback.Count(f => f.Email == feedback.Email);

            if (feedbackCount >= 5)
            {
                TempData["Error"] = "You have reached the limit! Only 5 feedbacks allowed per user.";
                return RedirectToAction("Dashboard", "Farmer");
            }

            try
            {
                _context.Feedback.Add(feedback);
                _context.SaveChanges();
                TempData["Success"] = "Feedback submitted successfully!";
                return RedirectToAction("Dashboard", "Farmer");
            }
            catch (DbUpdateException ex)
            {
                TempData["Error"] = "An error occurred while submitting feedback.";
            }
        }

        return View(feedback);
    }




}
