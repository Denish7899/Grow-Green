﻿using GROWGREEN.Models;
using GROWGREEN.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace GROWGREEN.Controllers
{
    public class FarmerController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly ISmsService _smsService;
        private readonly IConfiguration _configuration;

        public FarmerController(ApplicationDbContext context ,ISmsService smsService, IConfiguration configuration)
        {
            _context = context;
            _smsService = smsService;
            _configuration = configuration;
        }

        public IActionResult Chat()
        {
            var messages = _context.ChatMessages
                .OrderBy(m => m.Timestamp)
                .ToList();

            ViewBag.ChatMessages = messages;

            // Auto-fill username from session
            ViewBag.Username = HttpContext.Session.GetString("FarmerEmail")
                    ?? HttpContext.Session.GetString("ExpertEmail");
            return View();
        }

        public IActionResult Dashboard()
        {
            int farmerId = GetLoggedInFarmerId();
            if (farmerId == 0)
                return RedirectToAction("Login", "Account");

            var startedPrograms = _context.SelectedPrograms
                .Where(sp => sp.FarmerId == farmerId && sp.IsStarted == true)
                .Include(sp => sp.Program)
                .AsEnumerable()
                .Select(sp => new
                {
                    ProgramName = sp.Program.ProgramName,
                    CropName = sp.Program.CropName,
                    StartDate = sp.StartDate,
                    ImagePath = sp.Program.ImagePath,
                    Duration = sp.Program.TimeDuration,

                    RemainingDays = sp.StartDate.HasValue
                        ? (sp.StartDate.Value.AddDays(ParseDuration(sp.Program.TimeDuration)) - DateTime.Now).Days
                        : (int?)null
                })
                .ToList<dynamic>();

            var expertRequests = _context.ExpertRequests
                .Where(r => r.FarmerId == farmerId)
                .Select(r => new
                {
                    ExpertName = r.Expert.E_Name,
                    Expertise = r.Expert.E_Expertise,
                    Query = r.Query
                })
                .ToList();

            ViewBag.ExpertRequests = expertRequests;

            return View(startedPrograms);
        }

        private double ParseDuration(string timeDuration)
        {
            if (string.IsNullOrEmpty(timeDuration))
                return 0;

            // Take only the first number part
            string numberPart = new string(timeDuration.TakeWhile(c => char.IsDigit(c)).ToArray());

            if (double.TryParse(numberPart, out double days))
                return days;
            else
                return 0; // fallback
        }



        public IActionResult Experts()
        {
            var experts = _context.Expert.ToList();
            return View(experts);
        }

        public IActionResult QueryForm(int expertId)
        {
            var expert = _context.Expert.Find(expertId);
            if (expert == null)
                return NotFound();

            var model = new ExpertRequest
            {
                ExpertId = expert.E_Id,
                FarmerId = GetLoggedInFarmerId(),
                Query = ""
            };

            ViewBag.ExpertName = expert.E_Name;

            return View(model);
        }
        [HttpPost]
        public IActionResult SubmitExpertRequest(ExpertRequest model)
        {
            if (string.IsNullOrEmpty(model.Query))
            {
                ViewBag.ErrorMessage = "Query cannot be empty.";
                return View("QueryForm", model);
            }

            model.FarmerId = GetLoggedInFarmerId();
            model.RequestDate = DateTime.Now;

            _context.ExpertRequests.Add(model);
            _context.SaveChanges();

            TempData["SuccessMessage"] = "Your request has been submitted successfully!";
            return RedirectToAction("Dashboard");
        }

        public IActionResult ShowFarmingPrograms(string season = "All")
        {
            var programs = _context.FarmingPrograms
                .Include(f => f.Season)
                .AsQueryable();
            if (!string.IsNullOrEmpty(season) && season != "All")
            {
                programs = programs.Where(p => p.Season.SeasonName == season);
            }
            programs = programs.OrderByDescending(p => p.CreatedDate);

            ViewBag.SelectedSeason = season;

            return View(programs.ToList());
        }

        [HttpPost]
        public IActionResult SelectProgram(int programId)
        {
            int farmerId = GetLoggedInFarmerId();

            bool alreadySelected = _context.SelectedPrograms
                .Any(sp => sp.FarmerId == farmerId && sp.ProgramId == programId);

            if (!alreadySelected)
            {
                var selected = new SelectedProgram
                {
                    FarmerId = farmerId,
                    ProgramId = programId,
                    SelectedDate = DateTime.Now
                };

                _context.SelectedPrograms.Add(selected);
                _context.SaveChanges();
            }
            return RedirectToAction("SelectedFarmingPrograms");
        }

        public IActionResult SelectedFarmingPrograms()
        {
            int farmerId = GetLoggedInFarmerId();
            var today = DateTime.Today;
            var farmer = _context.Farmer.FirstOrDefault(f => f.F_Id == farmerId);
            var phoneNumber = farmer?.F_PhoneNo;

            var selectedPrograms = _context.SelectedPrograms
                .Where(sp => sp.FarmerId == farmerId)
                .Include(sp => sp.Program)
                    .ThenInclude(p => p.Season)
                .ToList()
                .Select(sp =>
                {
                    int durationDays = 0;
                    DateTime? endDate = null;
                    int? remainingDays = null;

                    var durationParts = sp.Program.TimeDuration?.Split('-');
                    if (durationParts != null && durationParts.Length == 2)
                    {
                        var minDurationPart = new string(durationParts[0].Where(char.IsDigit).ToArray());
                        var maxDurationPart = new string(durationParts[1].Where(char.IsDigit).ToArray());

                        int.TryParse(minDurationPart, out int minDays);
                        int.TryParse(maxDurationPart, out int maxDays);

                        durationDays = maxDays;

                        if (sp.StartDate != null)
                        {
                            endDate = sp.StartDate.Value.AddDays(durationDays);

                            if (sp.IsStarted)
                            {
                                remainingDays = Math.Max((endDate.Value - today).Days, 0);

                                // Send Reminder for 1-5 remaining days, only once per day
                                if (durationDays <= 10 && remainingDays > 0 && remainingDays <= 5 && phoneNumber != null)
                                {
                                    bool alreadySent = _context.ProgramReminders
                                        .Any(r => r.SelectedProgramId == sp.Id && r.RemainingDays == remainingDays);

                                    if (!alreadySent)
                                    {
                                        string message = $"Reminder: Only {remainingDays} day(s) left for your '{sp.Program.ProgramName}' program.";
                                        _smsService.SendSms(phoneNumber, message);

                                        _context.ProgramReminders.Add(new ProgramReminder
                                        {
                                            SelectedProgramId = sp.Id,
                                            RemainingDays = remainingDays.Value,
                                            SentDate = today
                                        });

                                        _context.SaveChanges();
                                    }
                                }

                                // Send message on last day
                                if (remainingDays == 0 && phoneNumber != null)
                                {
                                    bool alreadySent = _context.ProgramReminders
                                        .Any(r => r.SelectedProgramId == sp.Id && r.RemainingDays == 0);

                                    if (!alreadySent)
                                    {
                                        string message = $"Today is the last day for your '{sp.Program.ProgramName}' program!";
                                        _smsService.SendSms(phoneNumber, message);

                                        _context.ProgramReminders.Add(new ProgramReminder
                                        {
                                            SelectedProgramId = sp.Id,
                                            RemainingDays = 0,
                                            SentDate = today
                                        });

                                        _context.SaveChanges();
                                    }
                                }

                                // Long duration check-in every 15 days
                                if (durationDays > 30 && phoneNumber != null)
                                {
                                    int daysSinceStart = (today - sp.StartDate.Value).Days;
                                    if (daysSinceStart > 0 && daysSinceStart % 15 == 0)
                                    {
                                        bool alreadySent = _context.ProgramReminders
                                            .Any(r => r.SelectedProgramId == sp.Id && r.SentDate == today);

                                        if (!alreadySent)
                                        {
                                            string message = $"Update: Please check the health of your '{sp.Program.ProgramName}' crop and apply water/fertilizer as needed.";
                                            _smsService.SendSms(phoneNumber, message);

                                            _context.ProgramReminders.Add(new ProgramReminder
                                            {
                                                SelectedProgramId = sp.Id,
                                                RemainingDays = -1, // Use -1 for 15-day checks
                                                SentDate = today
                                            });

                                            _context.SaveChanges();
                                        }
                                    }
                                }
                            }
                        }
                    }

                    return new
                    {
                        sp.Id,
                        sp.Program.ProgramId,
                        sp.Program.ProgramName,
                        sp.Program.CropName,
                        sp.Program.SowingTime,
                        sp.Program.TimeDuration,
                        sp.Program.IrrigationSchedule,
                        sp.Program.FertilizerRecommendation,
                        SeasonName = sp.Program.Season.SeasonName,
                        sp.Program.ImagePath,
                        sp.SelectedDate,
                        sp.StartDate,
                        sp.IsStarted,
                        EndDate = endDate,
                        RemainingDays = remainingDays
                    };
                })
                .ToList<dynamic>();

            return View(selectedPrograms);
        }

    
        [HttpPost]
        public IActionResult RemoveSelectedProgram(int programId)
        {
            int farmerId = GetLoggedInFarmerId();

            var selectedProgram = _context.SelectedPrograms
                .FirstOrDefault(sp => sp.FarmerId == farmerId && sp.ProgramId == programId);

            if (selectedProgram != null)
            {
                _context.SelectedPrograms.Remove(selectedProgram);
                _context.SaveChanges();
            }
            return RedirectToAction("ShowFarmingPrograms");
        }

        private int GetLoggedInFarmerId()
        {
            return HttpContext.Session.GetInt32("FarmerId") ?? 0;
        }
        public IActionResult SubmittedQueries()
        {
            int farmerId = GetLoggedInFarmerId();
            if (farmerId == 0)
                return RedirectToAction("Login", "Account");

            var expertRequests = _context.ExpertRequests
                .Where(r => r.FarmerId == farmerId)
                .Select(r => new
                {
                    ExpertName = r.Expert.E_Name,
                    Expertise = r.Expert.E_Expertise,
                    Query = r.Query
                })
                .ToList();

            ViewBag.ExpertRequests = expertRequests;
            return View();
        }

        [HttpPost]
        public IActionResult SetStartDate(int selectedProgramId, DateTime startDate)
        {
            var selected = _context.SelectedPrograms.Find(selectedProgramId);
            if (selected != null)
            {
                selected.StartDate = startDate;
                _context.SaveChanges();
            }

            return RedirectToAction("SelectedFarmingPrograms");
        }

        [HttpPost]
        public IActionResult BeginProgram(int selectedProgramId)
        {
            var selected = _context.SelectedPrograms
                .Include(sp => sp.Program)
                .Include(sp => sp.Farmer)
                .FirstOrDefault(sp => sp.Id == selectedProgramId);

            if (selected != null && selected.StartDate.HasValue)
            {
                selected.IsStarted = true;
                _context.SaveChanges();

                string phoneNumber = selected.Farmer.F_PhoneNo;
                string crop = selected.Program.CropName;
                string date = selected.StartDate.Value.ToShortDateString();

                string message = $"🌱 GROWGREEN: Your crop program for {crop} has begun on {date}!";

                _smsService.SendSms(phoneNumber, message);
            }

            return RedirectToAction("SelectedFarmingPrograms");
        }



        public IActionResult ProgramDetails(int id)
        {
            var program = _context.FarmingPrograms
                .Include(p => p.Season)
                .FirstOrDefault(p => p.ProgramId == id);

            if (program == null)
            {
                return NotFound();
            }

            return View(program); 
        }

        public IActionResult ProgramDetailsByName(string name, string returnTo)
        {
            var program = _context.FarmingPrograms
                .Include(p => p.Season)
                .FirstOrDefault(p => p.ProgramName == name);

            if (program == null)
            {
                return NotFound();
            }
            ViewBag.ReturnTo = returnTo;

            return View("ProgramDetails", program);
        }



    }
}
