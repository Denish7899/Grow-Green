﻿using GROWGREEN.Models;
using Microsoft.AspNetCore.Mvc;

namespace GROWGREEN.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly OtpService _otpService;

        public AccountController(ApplicationDbContext context, OtpService otpService)
        {
            _context = context;
            _otpService = otpService;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            var admin = _context.Admin.FirstOrDefault(a => a.Email == email);
            var farmer = _context.Farmer.FirstOrDefault(f => f.F_Email == email);
            var expert = _context.Expert.FirstOrDefault(e => e.E_Email == email);

            if (admin != null)
            {
                string decryptedPassword = EncryptionHelper.DecryptPassword(admin.Password);
                if (decryptedPassword == password)
                {
                    HttpContext.Session.SetString("AdminEmail", admin.Name);
                    Console.WriteLine("Admin Login Successful!");
                    return RedirectToAction("Dashboard", "Admin");
                }
            }
            else if (farmer != null)
            {
                string decryptedPassword = EncryptionHelper.DecryptPassword(farmer.Password);
                if (decryptedPassword == password)
                {
                    HttpContext.Session.SetString("FarmerEmail", farmer.F_Name);
                    HttpContext.Session.SetInt32("FarmerId", farmer.F_Id);
                    Console.WriteLine("Farmer Login Successful!");
                    return RedirectToAction("Dashboard", "Farmer");
                }
            }
            else if (expert != null)
            {
                string decryptedPassword = EncryptionHelper.DecryptPassword(expert.E_Password);
                if (decryptedPassword == password)
                {
                    HttpContext.Session.SetString("ExpertEmail", expert.E_Name);
                    HttpContext.Session.SetInt32("ExpertId", expert.E_Id);
                    Console.WriteLine("Expert Login Successful!");
                    return RedirectToAction("Dashboard", "Expert");
                }
            }

            Console.WriteLine("Invalid credentials!");
            ViewBag.Error = "Invalid credentials";
            return View();
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var existingFarmer = _context.Farmer.FirstOrDefault(f => f.F_Email == model.F_Email);
                if (existingFarmer != null)
                {
                    ViewBag.Error = "Email already exists!";
                    return View(model);
                }

                string encryptedPassword = EncryptionHelper.EncryptPassword(model.Password);

                var farmer = new Farmer
                {
                    F_Name = model.F_Name,
                    F_Email = model.F_Email,
                    F_PhoneNo = "+91" + model.F_PhoneNo,
                    F_City = model.F_City,
                    F_Gender = model.F_Gender,
                    Password = encryptedPassword,
                    R_Date = DateTime.Today
                };

                _context.Farmer.Add(farmer);
                _context.SaveChanges();

                return RedirectToAction("Login", "Account");
            }

            ViewBag.Error = "Invalid form submission!";
            return View(model);
        }

        public IActionResult ForgotPassword()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ResetPassword(string email, string newPassword, string confirmPassword)
        {
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(newPassword) || string.IsNullOrEmpty(confirmPassword))
            {
                ViewBag.Error = "All fields are required!";
                ViewBag.IsResetStage = true;
                ViewBag.Email = email;
                return View("ForgotPassword");
            }

            if (newPassword != confirmPassword)
            {
                ViewBag.Error = "Passwords do not match!";
                ViewBag.IsResetStage = true;
                ViewBag.Email = email;
                return View("ForgotPassword");
            }

            var admin = _context.Admin.FirstOrDefault(a => a.Email == email);
            var farmer = _context.Farmer.FirstOrDefault(f => f.F_Email == email);
            var expert = _context.Expert.FirstOrDefault(e => e.E_Email == email);

            if ((admin != null && EncryptionHelper.DecryptPassword(admin.Password) == newPassword) ||
                (farmer != null && EncryptionHelper.DecryptPassword(farmer.Password) == newPassword) ||
                (expert != null && EncryptionHelper.DecryptPassword(expert.E_Password) == newPassword))
            {
                ViewBag.Error = "New password cannot be the same as old password!";
                ViewBag.IsResetStage = true;
                ViewBag.Email = email;
                return View("ForgotPassword");
            }

            if (admin != null)
            {
                admin.Password = EncryptionHelper.EncryptPassword(newPassword);
                _context.Admin.Update(admin);
            }
            else if (farmer != null)
            {
                farmer.Password = EncryptionHelper.EncryptPassword(newPassword);
                _context.Farmer.Update(farmer);
            }
            else if (expert != null)
            {
                expert.E_Password = EncryptionHelper.EncryptPassword(newPassword);
                _context.Expert.Update(expert);
            }
            else
            {
                ViewBag.Error = "Email not found!";
                ViewBag.IsResetStage = false;
                return View("ForgotPassword");
            }

            _context.SaveChanges();
            TempData["Success"] = "Password updated successfully!";
            return RedirectToAction("Login");
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            Response.Headers["Cache-Control"] = "no-cache, no-store, must-revalidate";
            Response.Headers["Pragma"] = "no-cache";
            Response.Headers["Expires"] = "0";
            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public IActionResult GetPassword(string email)
        {
            var admin = _context.Admin.FirstOrDefault(a => a.Email == email);
            var farmer = _context.Farmer.FirstOrDefault(f => f.F_Email == email);
            var expert = _context.Expert.FirstOrDefault(e => e.E_Email == email);

            if (admin != null)
            {
                return Json(new { success = true, email = admin.Email, oldPassword = admin.Password, role = "Admin" });
            }
            else if (farmer != null)
            {
                return Json(new { success = true, email = farmer.F_Email, oldPassword = farmer.Password, role = "Farmer" });
            }
            else if (expert != null)
            {
                return Json(new { success = true, email = expert.E_Email, oldPassword = expert.E_Password, role = "Expert" });
            }

            return Json(new { success = false });
        }

        [HttpGet]
        public IActionResult CheckEmailExists(string email)
        {
            bool exists = _context.Admin.Any(a => a.Email == email)
                         || _context.Farmer.Any(f => f.F_Email == email)
                         || _context.Expert.Any(e => e.E_Email == email);
            return Json(new { exists });
        }

        [HttpPost]
        public async Task<IActionResult> SendOtp([FromBody] string email)
        {
            await _otpService.GenerateAndSendOtp(email);
            return Json(new { success = true });
        }

        [HttpGet]
        public IActionResult VerifyOtp(string email, string otp)
        {
            var result = _otpService.VerifyOtp(email, otp);
            return Json(new { success = result });
        }
    }
}