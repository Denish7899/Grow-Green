﻿using GROWGREEN.Models;
using Microsoft.AspNetCore.Mvc;

namespace GROWGREEN.Controllers
{
    public class SeasonsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public SeasonsController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Season season)
        {
            if (ModelState.IsValid)
            {
                _context.Seasons.Add(season);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(season);
        }

        public IActionResult Index()
        {
            var seasons = _context.Seasons.ToList();
            return View(seasons);
        }

        public IActionResult Edit(int id)
        {
            var season = _context.Seasons.Find(id);
            if (season == null)
            {
                return NotFound();
            }
            return View(season);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Season season)
        {
            if (id != season.SeasonId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                _context.Seasons.Update(season);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(season);
        }

        public IActionResult Delete(int id)
        {
            var season = _context.Seasons.Find(id);
            if (season == null)
            {
                return NotFound();
            }
            return View(season);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var season = _context.Seasons.Find(id);
            if (season != null)
            {
                _context.Seasons.Remove(season);
                _context.SaveChanges();
            }
            return RedirectToAction("Index");
        }
    }
}
