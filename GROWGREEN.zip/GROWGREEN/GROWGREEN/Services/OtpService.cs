﻿using System.Collections.Concurrent;

public class OtpService
{
    private readonly EmailService _emailService;
    private static ConcurrentDictionary<string, string> otpStore = new();

    public OtpService(EmailService emailService)
    {
        _emailService = emailService;
    }

    public async Task GenerateAndSendOtp(string email)
    {
        string otp = new Random().Next(100000, 999999).ToString();
        otpStore[email] = otp;

        string body = $"<h2>Your GROWGREEN OTP is: <strong>{otp}</strong></h2>";
        await _emailService.SendEmailAsync(email, "Your OTP Code", body);
    }

    public bool VerifyOtp(string email, string inputOtp)
    {
        return otpStore.TryGetValue(email, out var otp) && otp == inputOtp;
    }
}
