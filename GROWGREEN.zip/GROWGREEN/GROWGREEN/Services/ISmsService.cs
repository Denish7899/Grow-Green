﻿namespace GROWGREEN.Services
{
    public interface ISmsService
    {
        void SendSms(string toPhoneNumber, string message);
    }
}
