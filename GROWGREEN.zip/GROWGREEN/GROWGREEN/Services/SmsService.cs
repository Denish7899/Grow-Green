﻿using Microsoft.Extensions.Configuration;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace GROWGREEN.Services
{
    public class SmsService : ISmsService
    {
        private readonly IConfiguration _configuration;

        public SmsService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void SendSms(string toPhoneNumber, string message)
        {
            var accountSid = _configuration["Twilio:AccountSID"];
            var authToken = _configuration["Twilio:AuthToken"];
            var fromPhone = _configuration["Twilio:FromPhone"];

            TwilioClient.Init(accountSid, authToken);

            var to = new PhoneNumber(toPhoneNumber);
            var from = new PhoneNumber(fromPhone);

            var msg = MessageResource.Create(
                to: to,
                from: from,
                body: message
            );

            Console.WriteLine($"📤 SMS sent to {toPhoneNumber}: {message}");
            Console.WriteLine($"✅ Twilio SID: {msg.Sid}");
        }

    }
}
